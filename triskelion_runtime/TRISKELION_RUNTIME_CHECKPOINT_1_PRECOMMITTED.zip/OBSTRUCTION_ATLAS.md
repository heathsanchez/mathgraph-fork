# Obstruction atlas

| ID | Classification | Observation | State |
|---|---|---|---|
| O-001 | H_OPERATOR | Frozen old closure cannot implement the zero-default contract | Closed by `PY.ZERO_DIVISION_DEFAULT.V1` |
| O-002 | H_COMPOSITION | Lexical execution order makes guard invisible after rounding | Closed in V1.1 by declared precedence |
| O-003 | H_SCOPE | Same division syntax has incompatible zero policies | Closed in bounded suite by declarative scope |
| O-004 | H_RESOURCE | River key is GitHub-scoped; Actions run 31837286924 received no runner and executed zero steps | INFRASTRUCTURE-BLOCKED |
| O-005 | H_RESOURCE | Six episodes are too small to amortize schema overhead | Open compression gate |
