# Negative lawbook

## N1 — Presence is not permission

Do not expose or execute every installed capability. Near-identical division code may require returning a default, raising, or returning `None`.

## N2 — Composition cannot use incidental identifier order

Run 001: rounding before guarding hid the syntactic structure required by the guard. Lexical registry order is not lawful composition order.

## N3 — No compression claim from Checkpoint 0

The six-task raw corpus was 3,113 bytes; structural registry state was 4,771 bytes. Small-stream schema overhead dominates.

## N4 — No neural learning claim

The executed proposer was deterministic. `gpt-5.6-luna` did not run.

