# Claims and evidence

| Claim | Status | Evidence |
|---|---|---|
| Executable capability survives without raw acquisition transcript | SUPPORTED | Run 002 fresh import passes |
| Capability is causally necessary on source-distinct task | SUPPORTED | Run 002 transfer passes; ablation fails |
| Scoped runtime beats always-on exposure in bounded suite | SUPPORTED | 6/6 vs 5/6; 0% vs 66.7% false activation |
| Closure can solve a composed task without promotion | CLOSURE | Two-capability composition passes; zero promotions |
| Persistent structure is smaller than raw memory | REJECTED at Checkpoint 0 scale | 4,791 registry bytes vs 3,113 corpus bytes |
| Frozen neural model improves with runtime | INFRASTRUCTURE-BLOCKED | Neural arm did not execute |
| Prior acquisition changes later discoverability | CANDIDATE | No frozen-budget `O1 → O2` discovery experiment yet |
