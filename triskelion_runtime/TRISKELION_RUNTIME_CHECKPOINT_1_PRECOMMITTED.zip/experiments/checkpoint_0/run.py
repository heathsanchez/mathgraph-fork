from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from triskelion.artifacts import apply_artifact
from triskelion.models import Capability, Task
from triskelion.runtime import Runtime
from triskelion.scope import matches_scope


SEED = 20260815
PROTOCOL_ID = "TRISKELION_CHECKPOINT_0_V1_1"
FROZEN_POLICY = {
    "executable_policy": "deterministic-constructor-v0",
    "neural_model": "gpt-5.6-luna",
    "neural_status": "INFRASTRUCTURE-BLOCKED",
    "reasoning_effort": "low",
    "max_output_tokens": 1800,
    "temperature": None,
}


def safe_capability() -> Capability:
    return Capability(
        capability_id="PY.ZERO_DIVISION_DEFAULT.V1",
        name="Guard zero divisor with numeric default",
        version="1.0.0", type="source_transform",
        artifact={"name": "guard_zero_division", "language": "python", "implementation": "triskelion.artifacts:guard_zero_division", "execution_order": 10},
        interface={"input": "python.source", "output": "python.source"},
        preconditions=["one Python function", "last argument is divisor", "direct division return"],
        postconditions=["zero divisor returns 0.0", "nonzero behavior preserved"],
        scope={"all": [
            {"field": "metadata.zero_division_policy", "equals": "return_default"},
            {"field": "metadata.zero_default", "equals": 0.0},
            {"field": "source", "contains": "/"},
        ]},
        applicability_test="declarative scope plus verifier-protected source test",
        dependencies=[], composes_with=["PY.ROUND_DIVISION_2.V1"], conflicts_with=[],
        acquired_from=["acquire_ratio_zero"],
        evidence=[], protected_tests=["acquire_ratio_zero", "transfer_average_zero", "near_zero_raises"],
        source_distinct_transfer=["transfer_average_zero"], ablation_status="pending",
        counterexamples=[], revocation_conditions=["any in-scope protected failure", "nonzero behavior regression"],
        discovery_cost={"constructor_evaluations": 1, "model_tokens": 0},
        execution_cost={"ast_passes": 1}, token_cost={"persistent_model_tokens": 0}, status="candidate",
    )


def round_capability() -> Capability:
    return Capability(
        capability_id="PY.ROUND_DIVISION_2.V1", name="Round division result to two decimals",
        version="1.0.0", type="source_transform",
        artifact={"name": "round_division", "language": "python", "implementation": "triskelion.artifacts:round_division", "execution_order": 20},
        interface={"input": "python.source", "output": "python.source"},
        preconditions=["direct division return"], postconditions=["nonzero division rounded to two decimals"],
        scope={"field": "metadata.round_digits", "equals": 2},
        applicability_test="metadata.round_digits == 2",
        dependencies=[], composes_with=["PY.ZERO_DIVISION_DEFAULT.V1"], conflicts_with=[],
        acquired_from=["seeded_prior_verified_capability"], protected_tests=["compose_safe_rounded"],
        ablation_status="not_applicable", revocation_conditions=["in-scope protected failure"],
        discovery_cost={"preexisting": True}, execution_cost={"ast_passes": 1}, token_cost={"persistent_model_tokens": 0},
        status="verified",
    )


def tasks() -> list[Task]:
    return [
        Task("acquire_ratio_zero", "def ratio(total, count):\n    return total / count\n", [
            {"function": "ratio", "args": [4, 2], "expected": 2.0},
            {"function": "ratio", "args": [0, 0], "expected": 0.0},
        ], {"zero_division_policy": "return_default", "zero_default": 0.0}, "acquisition", "authored-a"),
        Task("transfer_average_zero", "def average(total, items):\n    return total / items\n", [
            {"function": "average", "args": [5, 2], "expected": 2.5},
            {"function": "average", "args": [9, 0], "expected": 0.0},
        ], {"zero_division_policy": "return_default", "zero_default": 0.0}, "protected", "authored-b"),
        Task("near_zero_raises", "def quotient(total, count):\n    return total / count\n", [
            {"function": "quotient", "args": [6, 3], "expected": 2.0},
            {"function": "quotient", "args": [1, 0], "raises": "ZeroDivisionError"},
        ], {"zero_division_policy": "raise"}, "protected", "authored-c"),
        Task("near_zero_none", "def optional_ratio(total, count):\n    return total / count if count else None\n", [
            {"function": "optional_ratio", "args": [6, 3], "expected": 2.0},
            {"function": "optional_ratio", "args": [1, 0], "expected": None},
        ], {"zero_division_policy": "return_none"}, "protected", "authored-d"),
        Task("compose_safe_rounded", "def rate(total, count):\n    return total / count\n", [
            {"function": "rate", "args": [10, 3], "expected": 3.33},
            {"function": "rate", "args": [1, 0], "expected": 0.0},
        ], {"zero_division_policy": "return_default", "zero_default": 0.0, "round_digits": 2}, "protected", "authored-e"),
        Task("no_capability_needed", "def increment(value):\n    return value + 1\n", [
            {"function": "increment", "args": [4], "expected": 5},
        ], {"operation": "increment"}, "protected", "authored-f"),
    ]


def benchmark(runtime: Runtime, suite: list[Task]) -> dict:
    modes = ["cold", "raw_memory", "always_on", "verified"]
    result = {}
    for mode in modes:
        rows = [runtime.solve(task, mode) for task in suite]
        applicable_pairs = 0
        missed_pairs = 0
        false_selected = 0
        selected_pairs = 0
        for task, row in zip(suite, rows):
            for cap in runtime.registry.capabilities.values():
                applicable = cap.enabled and matches_scope(cap.scope, task)
                selected = cap.capability_id in row["selected"]
                applicable_pairs += int(applicable)
                missed_pairs += int(applicable and not selected)
                false_selected += int(selected and not applicable)
                selected_pairs += int(selected)
        successes = sum(row["verdict"]["passed"] for row in rows)
        result[mode] = {
            "verified_task_success": successes / len(rows),
            "passed": successes, "total": len(rows),
            "false_activation_rate": false_selected / selected_pairs if selected_pairs else 0.0,
            "missed_activation_rate": missed_pairs / applicable_pairs if applicable_pairs else 0.0,
            "model_tokens": 0,
            "latency_ms": round(sum(row["verdict"]["duration_ms"] for row in rows), 3),
            "rows": rows,
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise SystemExit("output directory already exists; refusing to overwrite frozen evidence")
    args.out.mkdir(parents=True)
    state = args.out / "state"
    runtime = Runtime(state)
    corpus = tasks()
    by_id = {task.task_id: task for task in corpus}
    (args.out / "RAW").mkdir()
    (args.out / "RAW" / "tasks.json").write_text(json.dumps([t.to_dict() for t in corpus], indent=2) + "\n")

    runtime.install(round_capability())
    acquisition = by_id["acquire_ratio_zero"]
    before = runtime.solve(acquisition, "verified")
    old_closure = runtime.closure(acquisition)

    candidate = safe_capability()
    candidate_source = apply_artifact(candidate.artifact["name"], acquisition.source)
    admission_verdict = runtime.verifier.verify(acquisition, candidate_source).to_dict()
    if not (not before["verdict"]["passed"] and not old_closure and admission_verdict["passed"]):
        raise RuntimeError("admission preconditions failed")
    candidate.evidence.append({"kind": "old_closure_failure", "verdict": before["verdict"]})
    candidate.evidence.append({"kind": "sufficiency", "verdict": admission_verdict})
    candidate.status = "verified"
    runtime.install(candidate)
    after = runtime.solve(acquisition, "verified")
    runtime.disable(candidate.capability_id)
    disabled = runtime.solve(acquisition, "verified")
    runtime.enable(candidate.capability_id)
    reenabled = runtime.solve(acquisition, "verified")

    transfer = runtime.solve(by_id["transfer_average_zero"], "verified")
    ablated = runtime.ablate(candidate.capability_id, by_id["transfer_average_zero"])
    candidate_live = runtime.registry.capabilities[candidate.capability_id]
    candidate_live.ablation_status = "passed" if transfer["verdict"]["passed"] and not ablated["verdict"]["passed"] else "failed"
    runtime.registry.save()

    export_path = args.out / "PY.ZERO_DIVISION_DEFAULT.V1.capability.json"
    runtime.export_capability(candidate.capability_id, export_path)
    fresh = Runtime(args.out / "fresh_reload_state")
    fresh.import_capability(export_path)
    reload_result = fresh.solve(acquisition, "verified")

    bench = benchmark(runtime, corpus)
    composition = runtime.compose(
        ["PY.ZERO_DIVISION_DEFAULT.V1", "PY.ROUND_DIVISION_2.V1"],
        by_id["compose_safe_rounded"],
    )
    registry_bytes = (state / "CAPABILITY_REGISTRY.json").stat().st_size
    raw_bytes = (args.out / "RAW" / "tasks.json").stat().st_size

    results = {
        "claim_class": "runtime-mechanics-only",
        "frozen_policy": FROZEN_POLICY,
        "seed": SEED,
        "install_uninstall": {
            "before_passed": before["verdict"]["passed"], "old_closure": old_closure,
            "candidate_verified": admission_verdict["passed"], "after_install_passed": after["verdict"]["passed"],
            "after_disable_passed": disabled["verdict"]["passed"], "after_reenable_passed": reenabled["verdict"]["passed"],
            "fresh_import_passed": reload_result["verdict"]["passed"],
        },
        "source_distinct_transfer": {"passed": transfer["verdict"]["passed"], "ancestor_ablation_passed": not ablated["verdict"]["passed"]},
        "closure_before_invention": {"composition_passed": composition["verdict"]["passed"], "new_promotions": 0},
        "benchmark": bench,
        "compression": {"raw_task_corpus_bytes": raw_bytes, "structural_registry_bytes": registry_bytes, "ratio_raw_to_structure": round(raw_bytes / registry_bytes, 4)},
        "environment": {"python": sys.version, "platform": platform.platform()},
    }
    (args.out / "RESULTS.json").write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")
    manifest = {
        "protocol": PROTOCOL_ID, "seed": SEED,
        "task_corpus_sha256": hashlib.sha256((args.out / "RAW" / "tasks.json").read_bytes()).hexdigest(),
        "capability_artifact_sha256": hashlib.sha256(export_path.read_bytes()).hexdigest(),
        "runtime_revision": "working-tree-checkpoint-0", "verifier": runtime.verifier.verifier_id,
        "frozen_policy": FROZEN_POLICY,
    }
    (args.out / "MANIFEST.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    observations = [
        ["install_demo", str(after["verdict"]["passed"]), "candidate installed closes acquisition task"],
        ["disable_demo", str(not disabled["verdict"]["passed"]), "disable restores failure"],
        ["reload_demo", str(reload_result["verdict"]["passed"]), "fresh state imports compact artifact"],
        ["transfer_ablation", str(not ablated["verdict"]["passed"]), "source-distinct task fails without capability"],
        ["scoped_beats_always", str(bench["verified"]["passed"] > bench["always_on"]["passed"]), "protected suite"],
        ["closure_composition", str(composition["verdict"]["passed"]), "two installed capabilities; no promotion"],
    ]
    with (args.out / "DEVELOPMENT_LEDGER.csv").open("w", newline="") as handle:
        writer = csv.writer(handle); writer.writerow(["observation", "passed", "detail"]); writer.writerows(observations)
    print(json.dumps({
        "out": str(args.out), "install": results["install_uninstall"],
        "transfer": results["source_distinct_transfer"],
        "benchmark": {k: {"passed": v["passed"], "total": v["total"], "false_activation_rate": v["false_activation_rate"]} for k, v in bench.items()},
    }, indent=2))


if __name__ == "__main__":
    main()
