# Checkpoint 0 frozen protocol

Protocol ID: `TRISKELION_CHECKPOINT_0_V1`; seed: `20260815`.

The executable substrate is `deterministic-constructor-v0`. The planned frozen neural arm is `gpt-5.6-luna`, reasoning effort `low`, maximum output 1,800 tokens, fixed structured response contract. It is `INFRASTRUCTURE-BLOCKED` in Checkpoint 0 because no model credential/endpoint is configured in the workspace. No deterministic result is evidence about neural-model improvement.

Domain: six deterministic Python source-repair tasks across six source groups. Verifier: isolated CPython subprocess with `-B`, `PYTHONDONTWRITEBYTECODE=1`, cache purge before/after, timeout, exact tests, and immediate successful-candidate replay.

Intervention: admit a scoped AST transformation that guards zero divisors only when the explicit contract says zero returns `0.0`. Protected negatives use nearly identical division code but require an exception or `None`.

Arms: COLD, RAW_MEMORY (guard lesson applied globally), ALWAYS_ON, VERIFIED. Same task order and installed registry are used. Metrics are exact task success, false/missed activation, verifier latency, model tokens, source-distinct reuse, ablation, and state bytes.

The run refuses to overwrite an existing output directory.

