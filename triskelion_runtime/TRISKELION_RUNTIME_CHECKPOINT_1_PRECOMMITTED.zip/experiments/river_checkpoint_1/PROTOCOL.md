# River Checkpoint 1 — frozen protocol

Protocol: `TRISKELION_RIVER_CHECKPOINT_1_V1`. Seed: `20260815`.

Frozen model: `Qwen/Qwen3.5-9B`. Availability is checked at runtime and the run fails rather than substituting another model. Sampling uses temperature `0.0`, maximum 512 generated tokens, one sample per task-arm pair, and deterministic per-pair seeds derived from the frozen task order.

Corpus: the unchanged six-task Checkpoint 0 protected suite. The model sees source, a deliberately sparse repair request, and public non-edge examples; it never sees protected tests or routing metadata. The runtime sees routing metadata.

Arms:

- COLD: no persistent memory or executable capability.
- RAW_MEMORY: an unscoped textual lesson plus its executable zero-guard interpretation.
- ALWAYS_ON: all installed capability descriptions and artifacts.
- VERIFIED: only capability descriptions and artifacts whose declared scopes match.

Each arm makes six model calls. Task order is unchanged. The model output must contain one Python code block; parse failure is a task failure. Selected executable artifacts are applied after the proposal, then the unchanged bytecode-safe verifier runs and immediately replays successes.

Primary gates: VERIFIED > COLD; VERIFIED > ALWAYS_ON; false activation VERIFIED < ALWAYS_ON; fresh source-distinct reuse; zero infrastructure errors. This protocol does not train or alter model weights.

