# Install / uninstall demo

Run the complete frozen demo:

```bash
python experiments/checkpoint_0/run.py --out /tmp/triskelion-demo
```

Read `/tmp/triskelion-demo/RESULTS.json`. The required path is recorded under `install_uninstall`:

1. before: failure;
2. old closure: empty;
3. candidate verifier: pass;
4. after install: pass;
5. after disable: failure;
6. after re-enable: pass;
7. fresh runtime import from `PY.ZERO_DIVISION_DEFAULT.V1.capability.json`: pass.

The fresh runtime directory contains no acquisition transcript.

